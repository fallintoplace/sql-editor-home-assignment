# Cathedral: local file import and result export features

Repository: `fallintoplace/sql-editor-home-assignment`
Target branch: `feat/cathedral-workbench`
Reviewed remote base: `67438c5ae2e3dbc82ad767469dd171b0f59b5e41`

## Status

Not pushed. This package is an implementation patch, not a green application release.
The connected GitHub actions available in this session were read-only. Command-line Git failed to resolve `github.com`; npm could not resolve `registry.npmjs.org`.

This combined 17-file patch INCLUDES the previous unpushed nine-file UX-feedback patch. Apply this instead of applying both packages. It does not contain a full repository, dependencies, a deployment, or a replacement Git history.

## New features

1. Import a UTF-8 SQL file or a Cathedral local-draft backup. Preview the drafts and select which to append. Both legacy raw version-1 backups and the new connection-labelled export are supported. Existing open/closed tabs are preserved. Imported drafts get new local IDs and lose all old server, run, script, dependency, and review references. No SQL execution, server save, data upload, or connection trust is triggered by import.
2. Choose which result columns to show, with search by name, type, and column position. Duplicate names remain independent positional columns. At least one column stays visible. Selections survive switching between Table and Chart for that mounted run; they are not saved and reset on a new run.
3. Export a filtered CSV with all matching retained rows across all pages and only the visible columns. The existing full CSV and Evidence JSON retain every row/column. Hidden columns still participate in row search and charts. Column hiding is not a privacy or authorization control.

The prior UX-feedback work included here adds saved-revision feedback, execution-limit validation, and searchable query history, including the pre-save and unnamed-script history visibility fixes.

## Limits and behavior

Files are limited to 5,000,000 bytes and must decode as UTF-8. SQL is limited to the application's existing 200,000-character string-length bound. Backup queues are limited to 30 open plus 10 recently closed drafts. Parameters remain exact strings, with at most 50 entries and 4,000 characters per value. Invalid required data rejects the entire preview; optional layout metadata is normalized with a visible notice.

There can be at most 30 open tabs after import. A full preview can contain more drafts than will fit; select a subset explicitly. The current tab capacity is checked again when confirming. Recently closed items chosen from a backup become new open drafts; they do not replace the existing closed-tab queue.

The modal shows the first 2,000 SQL characters per item as a preview. Import keeps the entire accepted SQL string. It reads files locally; choosing another file invalidates an earlier pending file read. Local browser persistence can still fail or reach quota, and the existing storage warning/export path remains relevant. A backup over 5 MB cannot be imported through this bounded importer.

A connection-labelled backup stores its connection ID and name, not host or credentials. SQL text itself can still contain sensitive literals. Treat backups as private data. Import drops old saved-revision and execution references even when the source connection label matches; save and execute explicitly when appropriate.

CSV uses the existing quoting and formula-prefix protections. CSV files retain large integer digits, but a spreadsheet application's automatic type inference can still reinterpret them. Evidence JSON remains the full retained data representation.

## Validation performed

- Strict workspace helper compilation using the actual shared types and verified source files: passed.
- 226 workspace/helper tests: 60 current branch tests, 93 prior UX-feedback tests, and 73 new feature tests. All passed, none skipped.
- Syntax checks on 12 changed/new TypeScript or TSX files: passed.
- `git diff --check`: passed.
- Patch application on a fresh verified affected-file snapshot: passed.
- All 17 post-apply outputs match the manifest's SHA-256 values.

The local toolchain was Node 22.16.0 and TypeScript 5.8.3. The dependency-aware full application typecheck/build, core suite, live ClickHouse integration, and browser tests did NOT run for this patch. Eleven new browser scenarios were authored; their syntax was checked, not their runtime behavior. The earlier 33-test green browser run validates the old commit only.

## Apply to a full checkout

Keep any unrelated changes safe first. Check out the target branch at the reviewed base. The script refuses a different HEAD, changed tracked files, conflicting new files, mismatching content, and symlink targets. It does not install packages, commit, or push.

Dry check:

```bash
python3 /path/to/cathedral-features/apply_patch.py /path/to/sql-editor-home-assignment
```

Apply after the check:

```bash
python3 /path/to/cathedral-features/apply_patch.py /path/to/sql-editor-home-assignment --apply
```

When the branch has newer commits, rebase/review the patch instead of bypassing the guard or resetting the branch.

## Validate in the full checkout

Use the repository's supported Node version and a development environment, not a production database.

```bash
cd /path/to/sql-editor-home-assignment/workbench
npm ci
npm test
npm run build
npx playwright install --with-deps chromium
npm run test:e2e
```

Also run the repository's existing live ClickHouse integration and SQL evaluations with its local development database setup. No live integration result is asserted by this package.

Only after those checks pass, stage the exact paths in `manifest.json`, review the diff, and commit using a message such as `feat: import local drafts and customize result exports`. Push normally to `feat/cathedral-workbench`; do not force-push. A newer remote branch should be incorporated before retrying.

## Contents

- `improvements.patch`: combined patch against the reviewed remote base.
- `changed-files/`: the exact 17 resulting source/test files.
- `manifest.json`: source Git blob hashes, output checksums, and push status.
- `apply_patch.py`: guarded dry-check/apply helper.
- `VERIFICATION.md`: scope and caveats.
- `logic-tests.txt`, `new-feature-tests.txt`, `syntax-check.txt`, `patch-verification.txt`: local validation evidence.
- `git-network-check.txt`: the observed Git access failure.
