#!/usr/bin/env python3
"""Verify and optionally apply this exact patch. Never commits, pushes, or installs dependencies."""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path, PurePosixPath


def git(repo: Path, *args: str) -> str:
    result = subprocess.run(
        ['git', '-C', str(repo), *args], capture_output=True, text=True, timeout=30,
    )
    if result.returncode:
        raise RuntimeError(f"git {' '.join(args)} failed: {result.stderr.strip() or 'check did not pass'}")
    return result.stdout.strip()


def blob(data: bytes) -> str:
    return hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repository', type=Path, help='Path to the full repository checkout')
    parser.add_argument('--apply', action='store_true', help='Apply after all checks pass; otherwise only verify')
    args = parser.parse_args()
    bundle = Path(__file__).resolve().parent
    manifest = json.loads((bundle / 'manifest.json').read_text(encoding='utf-8'))
    patch = bundle / 'improvements.patch'
    if hashlib.sha256(patch.read_bytes()).hexdigest() != manifest['patch_sha256']:
        raise RuntimeError('Patch checksum mismatch. Nothing was applied.')

    repo = Path(git(args.repository.resolve(), 'rev-parse', '--show-toplevel')).resolve()
    if git(repo, 'branch', '--show-current') != manifest['branch']:
        raise RuntimeError(f"Check out {manifest['branch']} first. Nothing was applied.")
    if git(repo, 'rev-parse', 'HEAD') != manifest['base_commit']:
        raise RuntimeError('HEAD differs from the reviewed base. Review/rebase the patch instead of overwriting newer work.')
    git(repo, 'diff', '--quiet')
    git(repo, 'diff', '--cached', '--quiet')

    for item in manifest['files']:
        relative = PurePosixPath(item['path'])
        if relative.is_absolute() or '..' in relative.parts or not relative.parts:
            raise RuntimeError('Invalid manifest path. Nothing was applied.')
        target = repo.joinpath(*relative.parts)
        if not target.resolve().is_relative_to(repo):
            raise RuntimeError(f"Path escapes the checkout: {relative}")
        for ancestor in [target, *target.parents]:
            if ancestor == repo:
                break
            if ancestor.is_symlink():
                raise RuntimeError(f"Refusing a symlink in the target path: {relative}")
        expected = item['before_blob']
        if expected is None:
            if target.exists():
                raise RuntimeError(f"A new-file target already exists: {relative}")
        elif not target.is_file() or blob(target.read_bytes()) != expected:
            raise RuntimeError(f"Original content does not match the reviewed blob: {relative}")
        prepared = bundle / 'changed-files' / Path(*relative.parts)
        if hashlib.sha256(prepared.read_bytes()).hexdigest() != item['after_sha256']:
            raise RuntimeError(f"Prepared-file checksum mismatch: {relative}")

    git(repo, 'apply', '--check', str(patch))
    if not args.apply:
        print(f"Verified {len(manifest['files'])} files and a clean patch application. No files changed.")
        print('Run the same command with --apply to apply the patch.')
        return

    git(repo, 'apply', str(patch))
    for item in manifest['files']:
        target = repo / item['path']
        if hashlib.sha256(target.read_bytes()).hexdigest() != item['after_sha256']:
            raise RuntimeError(f"Post-apply verification failed for {item['path']}. Inspect the working tree; no commit or push occurred.")
    print(f"Applied and verified {len(manifest['files'])} files. No commit or push occurred.")
    print('Run the complete application validation described in README.md before committing.')


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, RuntimeError, subprocess.TimeoutExpired) as error:
        print(f'ERROR: {error}', file=sys.stderr)
        sys.exit(1)
